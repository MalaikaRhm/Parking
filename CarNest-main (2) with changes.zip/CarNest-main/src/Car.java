

import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.*;

class Car extends JFrame {
    String name, color;
    String reg_no;
    Time arrivalTime;
    Time departureTime;
    JTextField tf1, tf2, tf3, tf4, tf5;
    JLabel jl, jl1, jl2, jl3, jl4, jl5;
    JFrame jf;
    JButton jb1, jb2;
    ImageIcon carImage;
    JLabel backgroundLabel;

    Car() {
        reg_no = "null";
        name = "null";
        color = "null";
    }

    Car(String regno, String nm, String clr, Time arrival, Time departure) {
        reg_no = regno;
        name = nm;
        color = clr;
        arrivalTime = arrival;
        departureTime = departure;
    }

    void EmptyCar() {
        name = "null";
        color = "null";
        reg_no = "null";
    }

    void set() {
        // frame
        jf = new JFrame("CAR'S INFO");
        jf.setBounds(100, 100, 800, 800); // Adjusted size
        carImage = new ImageIcon("background.jpg");
        backgroundLabel = new JLabel(carImage);
        jf.setContentPane(backgroundLabel);

        // title
        jl = new JLabel("CAR'S DETAILS");
        jl.setFont(new Font("Cooper Black", Font.PLAIN, 24)); // Adjusted font size
        jl.setForeground(new Color(231, 84, 128));
        jl.setBounds(250, 20, 400, 80); // Adjusted position
        jf.add(jl);

        // 1
        jl1 = new JLabel("Enter Plate#");
        jl1.setFont(new Font("Cooper Black", Font.PLAIN, 20)); // Adjusted font size
        jl1.setForeground(new Color(231, 84, 128));
        jl1.setBounds(50, 100, 200, 40); // Adjusted position and size
        jf.add(jl1);
        tf1 = new JTextField();
        tf1.setFont(new Font("Cooper Black", Font.PLAIN, 18)); // Adjusted font size
        tf1.setBounds(250, 100, 300, 40); // Adjusted position and size
        jf.add(tf1);

        // 2
        jl2 = new JLabel("Enter Name");
        jl2.setFont(new Font("Cooper Black", Font.PLAIN, 20)); // Adjusted font size
        jl2.setForeground(new Color(231, 84, 128));
        jl2.setBounds(50, 160, 200, 40); // Adjusted position and size
        jf.add(jl2);
        tf2 = new JTextField();
        tf2.setFont(new Font("Cooper Black", Font.PLAIN, 18)); // Adjusted font size
        tf2.setBounds(250, 160, 300, 40); // Adjusted position and size
        jf.add(tf2);

        // 3
        jl3 = new JLabel("Enter Color");
        jl3.setFont(new Font("Cooper Black", Font.PLAIN, 20)); // Adjusted font size
        jl3.setForeground(new Color(231, 84, 128));
        jl3.setBounds(50, 220, 200, 40); // Adjusted position and size
        jf.add(jl3);
        tf3 = new JTextField();
        tf3.setFont(new Font("Cooper Black", Font.PLAIN, 18)); // Adjusted font size
        tf3.setBounds(250, 220, 300, 40); // Adjusted position and size
        jf.add(tf3);

        // 4 (New) - Enter Arrival Time
        jl4 = new JLabel("Enter Arrival Time (HH:MM)");
        jl4.setFont(new Font("Cooper Black", Font.PLAIN, 20)); // Adjusted font size
        jl4.setForeground(new Color(231, 84, 128));
        jl4.setBounds(50, 280, 300, 40); // Adjusted position and size
        jf.add(jl4);
        tf4 = new JTextField();
        tf4.setFont(new Font("Cooper Black", Font.PLAIN, 18)); // Adjusted font size
        tf4.setBounds(350, 280, 200, 40); // Adjusted position and size
        jf.add(tf4);

        // 5 (New) - Enter Departure Time (optional)
        jl5 = new JLabel("Enter Departure Time (HH:MM)");
        jl5.setFont(new Font("Cooper Black", Font.PLAIN, 20)); // Adjusted font size
        jl5.setForeground(new Color(231, 84, 128));
        jl5.setBounds(50, 340, 300, 40); // Adjusted position and size
        jf.add(jl5);
        tf5 = new JTextField();
        tf5.setFont(new Font("Cooper Black", Font.PLAIN, 18)); // Adjusted font size
        tf5.setBounds(350, 340, 200, 40); // Adjusted position and size
        jf.add(tf5);

        // buttons
        jb1 = new JButton("OK");
        jb1.setFont(new Font("Cooper Black", Font.PLAIN, 12));
        jb1.setBounds(200, 400, 80, 40); // Adjusted position and size
        jb1.setBackground(new Color(231, 84, 128));
        jf.add(jb1);
        jb2 = new JButton("CLEAR");
        jb2.setFont(new Font("Cooper Black", Font.PLAIN, 12));
        jb2.setBackground(new Color(231, 84, 128));
        jb2.setBounds(400, 400, 80, 40); // Adjusted position and size
        jf.add(jb2);

        jb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reg_no = tf1.getText();
                name = tf2.getText();
                color = tf3.getText();

                String[] arrivalTimeParts = tf4.getText().split(":");
                arrivalTime = new Time(Integer.parseInt(arrivalTimeParts[0]), Integer.parseInt(arrivalTimeParts[1]));

                if (!tf5.getText().isEmpty()) {
                    String[] departureTimeParts = tf5.getText().split(":");
                    departureTime = new Time(Integer.parseInt(departureTimeParts[0]), Integer.parseInt(departureTimeParts[1]));
                } else {
                    departureTime = null;
                }

                jf.dispose();
            }
        });

        jb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tf1.setText("");
                tf2.setText("");
                tf3.setText("");
                tf4.setText("");
                tf5.setText("");
            }
        });

        jf.setLayout(null);
        jf.setVisible(true);
    }

//    void Receipt() {
//        System.out.println("Receipt");
//        System.out.println("Car Reg No: " + reg_no);
//        System.out.println("Name: " + name);
//        System.out.println("Color: " + color);
//        System.out.print("Arrival Time: ");
//        System.out.println(arrivalTime.Show());
//        if (departureTime != null) {
//            System.out.print("Departure Time: ");
//            System.out.println(departureTime.Show());
////            departureTime.Show();
//            
//        } else {
//            System.out.println("Departure Time: N/A");
//        }
//        System.out.println("Bill: $" + arrivalTime.totalPrice(departureTime));
//    }
    
    void Receipt() {
        JFrame receiptFrame = new JFrame("Receipt");
        receiptFrame.setSize(400, 300);
        receiptFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        receiptFrame.setLayout(new BorderLayout());

        JPanel receiptPanel = new JPanel();
        receiptPanel.setLayout(new GridLayout(6, 1));

        JLabel regNoLabel = new JLabel("Car Reg No: " + reg_no);
        JLabel nameLabel = new JLabel("Name: " + name);
        JLabel colorLabel = new JLabel("Color: " + color);
        JLabel arrivalTimeLabel = new JLabel("Arrival Time: " + arrivalTime.Show());
        JLabel departureTimeLabel = new JLabel("Departure Time: " + (departureTime != null ? departureTime.Show() : "N/A"));
        JLabel billLabel = new JLabel("Bill: $" + arrivalTime.totalPrice(departureTime));

        receiptPanel.add(regNoLabel);
        receiptPanel.add(nameLabel);
        receiptPanel.add(colorLabel);
        receiptPanel.add(arrivalTimeLabel);
        receiptPanel.add(departureTimeLabel);
        receiptPanel.add(billLabel);

        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> receiptFrame.dispose());

        receiptFrame.add(receiptPanel, BorderLayout.CENTER);
        receiptFrame.add(okButton, BorderLayout.SOUTH);
        receiptFrame.setVisible(true);
    }
}
