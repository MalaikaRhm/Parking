

class Time {
    int hh;
    int mm;

    Time() {
        hh = 0;
        mm = 0;
    }

    Time(int h, int m) {
        hh = h;
        mm = m;
    }

    String Show() {
        return (hh + ":" + mm);
    }

    int calculateMinutes() {
        return hh * 60 + mm;
    }

    
    int totalPrice(Time end) {
        int startMinutes = this.calculateMinutes();
        int endMinutes = end.calculateMinutes();
        int durationMinutes = endMinutes - startMinutes;
        // Calculate the total price based on $4 for every 2 minutes
        return (durationMinutes / 2) * 4;
    }

}
