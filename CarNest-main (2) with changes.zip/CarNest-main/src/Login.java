import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Login extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel messageLabel;
    
    

    public Login() {
        setTitle("Login");
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 80, 25);
       
        add(usernameLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(150, 50, 165, 25);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 80, 25);
        add(passwordLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(150, 100, 165, 25);
        add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(150, 150, 80, 25);
        add(loginButton);

        messageLabel = new JLabel();
        messageLabel.setBounds(50, 200, 300, 25);
        add(messageLabel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (validateLogin(username, password)) {
                    openParkingLot();
                } else {
                    messageLabel.setText("Invalid username or password");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });
    }

    private boolean validateLogin(String username, String password) {
        // Simple validation (you can change the credentials as needed)
        return username.equals("admin") && password.equals("password");
//    	return username == "admin" && password == "password";
        
    }

    private void openParkingLot() {
        // Close the login window
        dispose();

        // Open the ParkingLot window
        ParkingLot parkingLot = new ParkingLot();
        parkingLot.setVisible(true);
    }

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
}
